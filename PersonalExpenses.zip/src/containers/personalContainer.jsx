/** (c) Walgreen Co. All rights reserved.**/
import React, { Component } from 'react';
import { connect } from 'react-redux';
import PersonalComponentItem from '../components/personalComponent.jsx';
export class PersonalContainer extends Component {
	constructor(props) {
        super(props);
    }
	render() {
		return <PersonalComponentItem {...this.props}/>;
	}
}
const mapStateToProps = (state) => {
    const { personalDetails }=state;
	return {
        personalDetails
    };
};
export default connect(
	mapStateToProps
)(PersonalContainer);
